import React, { Component } from 'react'

//function Greet(){
  //  return <h1> Hello Lohitha</h1>
//}
class Welcome extends Component{
    render(){
      const {name,favouriteAnimal} = this.props
      //const  {state1,state2} =this.state
      return (
        <h1>
          Welcome {name} a.k.a {favouriteAnimal}</h1>
      )  
  }

}


export default Welcome