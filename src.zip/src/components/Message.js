import React, { Component } from 'react'

//function Greet(){
  //  return <h1> Hello Lohitha</h1>
//}
class Message extends Component{

    constructor(){
        super()
        this.state={
            message: 'Welcome visitor'
        }
    }
    changeMessage(){
        this.setState({
            message: 'going to login in'
        })
    }
    render(){
        
        return(
        <div>
        <h1>{this.state.message}</h1>
        <button onClick={() => this.changeMessage()}>Click</button>
        </div>
        )    
}
}


export default Message