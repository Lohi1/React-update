import React, { Component } from 'react'

import './App.css';
import Greet from './components/Greet'
import Welcome from './components/Welcome'
import Hello from './components/Hello'
import Message from './components/Message'
import Counter from './components/Counter'
import FunctionClick from './components/FunctionClick'
import ClassClick from './components/ClassClick'
import EventBind from './components/EventBind'
import UserGreeting from './components/UserGreeting'
import ChildComponent from './components/ChildComponent'
import NameList from './components/NameList'
class App extends Component{
  render(){
  return (
    <div className="App">
      <ChildComponent/>
      <NameList/>
      {/* <EventBind/> */}
      <UserGreeting/>
      {/* <FunctionClick/> */}
      {/* <ClassClick/> */}
        {/* <Message /> 
      <Counter/>

       <Greet name= "Shekar" favouriteAnimal="Lion">

       <p>This is animal props</p></Greet>
      <Greet name= "Radha" favouriteAnimal="Tiger" />
      <button>Click</button>
      <Greet name= "Krishna" favouriteAnimal="Lepord"/> */}
      {/* <Greet name= "Sony" favouriteAnimal="Horse"/>
         <Welcome  name= "Shekar" favouriteAnimal="Lion" />
      <Welcome name= "Radha" favouriteAnimal="Tiger" />
      <Welcome name= "Krishna" favouriteAnimal="Lepord" />
      <Welcome name= "Sony" favouriteAnimal="Horse" /> 
  <Hello />   */} 
      
    </div>
  );
 }
}
export default App;
